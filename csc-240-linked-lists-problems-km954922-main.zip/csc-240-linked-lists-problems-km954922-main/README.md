[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-718a45dd9cf7e7f842a935f5ebbe5719a5e09af4491e668f4dbf3b35d5cca122.svg)](https://classroom.github.com/online_ide?assignment_repo_id=11105931&assignment_repo_type=AssignmentRepo)
# CSC240-LinkedLists

[![Points badge](../../blob/badges/.github/badges/points.svg)](../../actions)

1. [DuplicatesProblem](DuplicatesProblem.java)
2. [MergeProblem](MergeProblem.java)
3. [IndexRemoveProblem](IndexRemoveProblem.java)
4. [RemoveElementsProblem](RemoveElementsProblem.java)
5. [BinaryToDecimalProblem](BinaryToDecimalProblem.java)

